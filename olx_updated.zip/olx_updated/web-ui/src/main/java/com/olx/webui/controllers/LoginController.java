package com.olx.webui.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.olx.webui.pojo.UserPojo;

@Controller
public class LoginController {
	
	@Autowired
	private DiscoveryClient discoveryClient;
	
	@PostMapping(value="/signin")
	public ModelAndView signin(@ModelAttribute("id") String id, @ModelAttribute("password") String password, HttpServletRequest req){
				
		List<ServiceInstance> instances = discoveryClient.getInstances("user-service"); 
		ServiceInstance serviceInstance=instances.get(0);
		String baseUrl=serviceInstance.getUri().toString();
		RestTemplate restTemplate = new RestTemplate();
		String url = null;
		ModelAndView mav = new ModelAndView();
	    
		url=baseUrl+"/phoneandpass/{phoneNo},{password}";
	    Map<String, String> params = new HashMap<String, String>();
	    params.put("phoneNo", id);
	    params.put("password", password);	     
	    UserPojo user = restTemplate.getForObject(url, UserPojo.class, params);
	    if(user!=null){
	    	HttpSession session=req.getSession();
 			session.setAttribute("user", user);
	    	mav.setViewName("home");
	    	return mav;
	    }
		
		url=baseUrl+"/emailandpass/{emailId},{password}";
	    params = new HashMap<String, String>();
	    params.put("emailId", id);
	    params.put("password", password);	     
	    user = restTemplate.getForObject(url, UserPojo.class, params);
	    if(user!=null){
	    	HttpSession session=req.getSession();
 			session.setAttribute("user", user);
	    	mav.setViewName("home");
	    	return mav;
	    }
	    
	    mav.addObject("error", "Wrong Credentials");
	    mav.setViewName("LoginForm");
	    return mav;
		
	}
}
