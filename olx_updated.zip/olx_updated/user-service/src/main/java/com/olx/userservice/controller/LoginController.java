package com.olx.userservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.olx.userservice.pojo.UserPojo;
import com.olx.userservice.service.LoginService;

@RestController
public class LoginController {
	
	@Autowired
 	public LoginService loginservice;
	
	@RequestMapping(value = "/phoneandpass/{phoneNo},{password}", method = RequestMethod.GET)
    public UserPojo getPhoneNo(@PathVariable("phoneNo") String phoneNo, @PathVariable("password") String password) {
		return loginservice.findByPhoneNoAndPassword(phoneNo, password);
    }
	
	@RequestMapping(value = "/emailandpass/{emailId},{password}", method = RequestMethod.GET)
	public UserPojo getEmailId(@PathVariable("emailId") String emailId, @PathVariable("password") String password) {
	    return loginservice.findByEmailIdAndPassword(emailId, password);
	}

}
