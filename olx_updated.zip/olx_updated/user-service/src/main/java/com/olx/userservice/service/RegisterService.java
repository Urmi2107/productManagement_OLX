package com.olx.userservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.olx.userservice.pojo.UserPojo;
import com.olx.userservice.repository.RegisterRepository;



@Service
public class RegisterService {
@Autowired
public RegisterRepository registerRepo;
public UserPojo addregister(UserPojo register) {
	// TODO Auto-generated method stub
	return registerRepo.save(register);
}





public List<UserPojo> findAll() {
	return registerRepo.findAll();
}

public UserPojo findByPhoneNo(String phoneNo) {
	// TODO Auto-generated method stub
	return registerRepo.findByPhoneNo(phoneNo) ;
}

public UserPojo findByEmailId(String emailId) {
	// TODO Auto-generated method stub
	return registerRepo.findByEmailId(emailId);
}
public UserPojo updateregister(UserPojo register) {
	// TODO Auto-generated method stub
	return registerRepo.save(register);
}
	
}

